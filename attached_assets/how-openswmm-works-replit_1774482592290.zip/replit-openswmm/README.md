# How OpenSWMM Works

Technical deep-dive into the HydroCouple OpenSWMM Engine (v6.0.0-alpha.1).

## What This Is

A self-contained documentation app that explains the architecture and internals of [Caleb Buahin's OpenSWMM engine](https://github.com/HydroCouple/openswmm.engine/tree/swmm6_rel) — the community-driven continuation of EPA SWMM.

Covers:
- Two-engine architecture (legacy 5.x solver + new 6.0 C++20 engine)
- All 322 C API functions across 18 domain-specific headers
- Simulation loop physics (runoff → dynamic wave → quality → LID → inlets)
- Numerical methods (Cash-Karp RK5, Ridder's root finder, Kahn's topo sort)
- Plugin system for I/O
- Hot start file format
- Complete source code map

## Running

Click **Run** in Replit, or locally:

```bash
python3 -m http.server 3000
```

Then open http://localhost:3000

## Files

- `index.html` — the full app (markdown rendered with marked.js + highlight.js)
- `how_openswmm_works.md` — raw markdown source
- `.replit` / `replit.nix` — Replit configuration

## Source

- [HydroCouple/openswmm.engine (swmm6_rel)](https://github.com/HydroCouple/openswmm.engine/tree/swmm6_rel)
- [USEPA/Stormwater-Management-Model](https://github.com/USEPA/Stormwater-Management-Model) (EPA SWMM 5.2.4 baseline)
- Built for [SWMM5.org](https://swmm5.org)
